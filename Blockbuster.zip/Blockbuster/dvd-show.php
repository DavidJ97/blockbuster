<?php

if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('class/CRUD.php');
    $crud = new CRUD;
    $Films = $crud->selectId('Films', $id);

    // foreach($client as $key=>$value){
    //     $$key=$value;
    // }

     extract($Films);
     



}else{
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>client</title>
</head>
<body>
<h1>Films</h1>
    <table>
        <tr>
            <td><strong>Titre:</strong></td>
            <td><?= $titre; ?></td>
        </tr>
        <tr>
            <td><strong>Année:</strong></td>
            <td><?= $annee; ?></td>
        </tr>
        <tr>
            <td><strong>Genre:</strong></td>
            <td><?= $genre; ?></td>
        </tr>
        <tr>
            <td><strong>Réalisateur:</strong></td>
            <td><?= $realisateur; ?></td>
        </tr>
        <tr>
            <td><strong>Durée:</strong></td>
            <td><?= $duree; ?> min</td>
        </tr>
        <tr>
            <td><strong>Description:</strong></td>
            <td><?= $description; ?></td>
        </tr>
    </table>
    <a href="dvd-edit.php?id=<?= $id; ?>">Modifier</a>
    <form action="dvd-delete.php" method="post">
        <input type="hidden" name="id" value="<?= $id; ?>">
        <br>
        <input type="submit" value="Delete">
    </form>
</body>
</html>