<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Ajouter un utilisateur</title>
</head>
<body>
    <form action="user-store.php" method="post">
    <h1>Ajouter un utilisateur</h1>
        <label>Nom
            <input type="text" name="nom">
        </label>
        <label>Prénom
            <input type="text" name="prenom">
        </label>
        <label>Email
            <input type="email" name="email">
        </label>
        <label>Mot de passe
            <input type="password" name="mot_de_passe">
        </label>
        <label>Est administrateur ?
            <input type="checkbox" name="est_admin">
        </label>
        <input type="submit" value="Enregistrer">
    </form>
    <a href="index.php">retour à l'index </a> <!-- Lien pour accéder à la page show-user.php -->
</body>
</html>
