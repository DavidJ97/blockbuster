<?php
require_once('class/CRUD.php');

$crud = new CRUD;
$delete = $crud->delete('Utilisateurs', $_POST['id']);

header('location:index.php');
?>
