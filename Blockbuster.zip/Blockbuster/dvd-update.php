<?php
require_once('class/CRUD.php');

$crud = new CRUD;
$update = $crud->update('Films', $_POST);

header('Location: index.php');

?>
