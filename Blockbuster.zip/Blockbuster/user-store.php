<?php 
require_once('class/CRUD.php');

$crud = New CRUD;
$insert = $crud->insert('Utilisateurs', $_POST);

header("location:user-show.php?id=$insert");
?>
