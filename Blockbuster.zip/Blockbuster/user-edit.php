<?php
if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('class/CRUD.php');
    $crud = new CRUD;
    $user = $crud->selectId('Utilisateurs', $id);
    extract($user);
}else{
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Modifier un utilisateur</title>
</head>
<body>
    <h1>Modifier un utilisateur</h1>
    <form action="user-update.php" method="post">
        <input type="hidden" name="id" value="<?= $id; ?>">
        <label>Nom
            <input type="text" name="nom" value="<?= $nom; ?>">
        </label>
        <label>Prénom
            <input type="text" name="prenom"  value="<?= $prenom; ?>">
        </label>
        <label>Email
            <input type="email" name="email"  value="<?= $email; ?>">
        </label>
        <label>Mot de passe
            <input type="password" name="mot_de_passe"  value="<?= $mot_de_passe; ?>">
        </label>
        <label>Est admin?
            <input type="checkbox" name="est_admin" value="1" <?= ($est_admin ? 'checked' : ''); ?>>
        </label>
        <input type="submit" value="Mettre à jour">
    </form>
    
</body>
</html>
