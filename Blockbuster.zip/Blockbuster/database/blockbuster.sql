-- blockbuster.sql

-- Création de la table Utilisateurs
CREATE TABLE Utilisateurs (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    prenom VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    est_admin BOOLEAN DEFAULT FALSE
);
-- Ajout des utilisateurs
INSERT INTO Utilisateurs (nom, prenom, email, mot_de_passe, est_admin)
VALUES
('Dupont', 'Jean', 'jean.dupont@email.com', 'motdepasse123', FALSE),
('Martin', 'Claire', 'claire.martin@email.com', 'motdepasse456', FALSE),
('Leroy', 'Marc', 'marc.leroy@email.com', 'motdepasse789', FALSE),
('Petit', 'Sophie', 'sophie.petit@email.com', 'motdepasse101', FALSE),
('Roux', 'Pierre', 'pierre.roux@email.com', 'motdepasse112', FALSE),
('Moreau', 'Lucie', 'lucie.moreau@email.com', 'motdepasse131', FALSE),
('Garcia', 'Paul', 'paul.garcia@email.com', 'motdepasse415', FALSE),
('Lambert', 'Marie', 'marie.lambert@email.com', 'motdepasse617', FALSE),
('Dubois', 'Julie', 'julie.dubois@email.com', 'motdepasse819', FALSE),
('Durand', 'Guillaume', 'guillaume.durand@email.com', 'motdepasse102', FALSE);

-- Création de la table Genre
CREATE TABLE Genre (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) UNIQUE NOT NULL
);
-- Ajout des genres
INSERT INTO Genre (nom) VALUES
    ('Crime'),
    ('Science Fiction'),
    ('Drame'),
    ('Aventure'),
    ('Thriller'),
    ('Western'),
    ('Horreur'),
    ('Action');

-- Création de la table DVD (Films)
CREATE TABLE Films (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    annee INT(4) NOT NULL,
    genre VARCHAR(255),
    realisateur VARCHAR(255) NOT NULL,
    duree INT NOT NULL,
    description TEXT NOT NULL,
    image VARCHAR(255) NOT NULL,
    FOREIGN KEY (genre) REFERENCES Genre(nom)
);

-- Création de la table Location
CREATE TABLE Location (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT(6) UNSIGNED NOT NULL,
    film_id INT(6) UNSIGNED NOT NULL,
    date_location DATE NOT NULL,
    date_retour DATE,
    FOREIGN KEY (utilisateur_id) REFERENCES Utilisateurs(id),
    FOREIGN KEY (film_id) REFERENCES Films(id)
);

-- Insertion des films
INSERT INTO Films (titre, annee, genre, realisateur, duree, description, image) VALUES
    ('Pulp Fiction', 1994, 'Crime', 'Quentin Tarantino', 154, 'Lhistoire de plusieurs criminels interconnectes a Los Angeles.', 'Pulp_Fiction.jpg'),
    ('The Godfather', 1972, 'Crime', 'Francis Ford Coppola', 175, 'Le patriarche dune famille criminelle du crime organise transfere le pouvoir a son fils.', 'The_Godfather.jpg'),
    ('Star Wars: Episode IV - A New Hope', 1977, 'Science Fiction', 'George Lucas', 121, 'Un jeune fermier, un contrebandier et un chevalier Jedi sunissent pour sauver la galaxie.', 'Star_Wars_Episode_IV.jpeg'),
    ('Back to the Future', 1985, 'Science Fiction', 'Robert Zemeckis', 116, 'Un adolescent voyage dans le temps avec laide dun scientifique excentrique.', 'Back_to_the_Future.jpg'),
    ('The Shawshank Redemption', 1994, 'Drame', 'Frank Darabont', 142, 'Lhistoire de lamitie entre deux detenus condamnes a la prison de Shawshank.', 'The_Shawshank_Redemption.jpg'),
    ('Casablanca', 1942, 'Drame', 'Michael Curtiz', 102, 'Un proprietaire de club et son ancien amour sont reunis a Casablanca pendant la Seconde Guerre mondiale.', 'Casablanca.jpeg'),
    ('Raiders of the Lost Ark', 1981, 'Aventure', 'Steven Spielberg', 115, 'Larcheologue Indiana Jones part a la recherche de lArche dAlliance.', 'Raiders_of_the_Lost_Ark.jpeg'),
    ('E.T. the Extra-Terrestrial', 1982, 'Science Fiction', 'Steven Spielberg', 115, 'Un garcon fait equipe avec un extraterrestre pour le ramener chez lui.', 'E.T. _the_Extra-Terrestrial.jpeg'),
    ('The Silence of the Lambs', 1991, 'Thriller', 'Jonathan Demme', 118, 'Une jeune recrue du FBI consulte le Dr. Hannibal Lecter pour traquer un tueur en serie.', 'The_Silence_of_the_Lambs.jpeg'),
    ('The Good, the Bad and the Ugly', 1966, 'Western', 'Sergio Leone', 161, 'Trois hommes cherchent un tresor pendant la Guerre civile americaine.', 'The Good,_the_Bad_and_the_Ugly.jpeg'),
    ('One Flew Over the Cuckoos Nest', 1975, 'Drame', 'Milos Forman', 133, 'Un homme simule la folie pour echapper a la prison et se retrouve dans un hopital psychiatrique.', 'One_Flew_Over_the Cuckoos _Nest.jpeg'),
    ('The Empire Strikes Back', 1980, 'Science Fiction', 'Irvin Kershner', 124, 'Les rebelles affrontent lEmpire galactique.', 'The_Empire_Strikes_Back.jpeg'),
    ('The Shining', 1980, 'Horreur', 'Stanley Kubrick', 146, 'Un ecrivain en herbe devient fou dans un hotel isole.', 'The_Shining.jpeg'),
    ('The Matrix', 1999, 'Science Fiction', 'Wachowskis', 136, 'Un pirate informatique decouvre la verite sur la realite.', 'The_Matrix.jpeg'),
    ('Gladiator', 2000, 'Action', 'Ridley Scott', 155, 'Un general romain cherche a se venger de lempereur qui a tue sa famille et la condamne a lesclavage.', 'Gladiator.jpeg'),
    ('Blade Runner', 1982, 'Science Fiction', 'Ridley Scott', 117, 'Un detective traque des repliques humaines dans un futur dystopique.', 'Balde_Runner.jpeg');
