<?php
require_once('class/CRUD.php');

$crud = new CRUD;
$update = $crud->update('Utilisateurs', $_POST);

header('Location: index.php');

?>
