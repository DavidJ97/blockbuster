<?php
require_once('class/CRUD.php');

$crud = new CRUD;
$delete = $crud->delete('Films', $_POST['id']);

header('location:index.php');
?>