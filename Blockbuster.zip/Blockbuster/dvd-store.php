<?php 
require_once('class/CRUD.php');

$crud = New CRUD;
$insert =$crud->insert('Films', $_POST);

header("location:dvd-show.php?id=$insert");