<?php
require_once('class/CRUD.php');
$crud = new CRUD;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>ajouter un dvd</title>
    
</head>
<body>

    <form action="dvd-store.php" method="post">  
         <h1>Ajouter un dvd</h1>
        <label>Titre
            <input type="text" name="titre">
        </label>
        <label>Année
            <input type="text" name="annee">
        </label>
        <label>genre
            <input type="text" name="genre">
        <label>Réalisateur
            <input type="text" name="realisateur">
        </label>
        <label>Description
            <input type="text" name="description">
        </label>
        <label>Durée
            <input type="text" name="duree">
        </label>
        <input type="submit" value="save">
    </form>
    <a href="index.php">retour à l'index </a> <!-- Lien pour accéder à la page show-user.php -->
</body>
</html>