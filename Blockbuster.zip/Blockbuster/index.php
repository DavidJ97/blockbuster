<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once('class/CRUD.php');
$crud = new Crud;
$film = $crud->select('Films', 'titre');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blockbuster</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<img src="images/blockbuster-logo.png" alt="Blockbuster Logo" width="220" height="120">
<div class="btn-container">
    <a href="add-dvd.php" class="btn">Ajouter un DVD</a>
    <a href="add-user.php" class="btn">Ajouter un utilisateur</a>
  
</div>

    <table>
        <th>Titre</th>
        <th>Année</th>
        <th>Genre</th>
        <th>Réalisateur</th>
        <th>Durée</th>
        <th>Description</th>
        <th>Images</th>
    <?php 
    foreach ($film as $row) {
        ?>
        <tr>
        <td><a href="dvd-show.php?id=<?= $row['id']?>"><?= $row['titre']?></a></td>
        <td><?= $row['annee']?></td>
        <td><?= $row['genre']?></td>
        <td><?= $row['realisateur']?></td>
        <td><?= $row['duree']?> min</td>
        <td><?= $row['description']?></td>
        <td><img src="images/<?= $row['image']?>" alt="<?= $row['titre']?>" style="width: 100px;"></td>

    </tr>
    <?php 
    }
    ?>
    </table>
 
</html>