<?php
if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('class/CRUD.php');
    $crud = new CRUD;
    $film = $crud->selectId('Films', $id);
    extract($film);
}else{
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Modifier un film</title>
</head>
<body>
    <h1>Modifier un film</h1>
    <form action="dvd-update.php" method="post">
        <input type="hidden" name="id" value="<?= $id; ?>">
        <label>Titre
            <input type="text" name="titre" value="<?= $titre; ?>">
        </label>
        <label>Année
            <input type="text" name="annee"  value="<?= $annee; ?>">
        </label>
        <label>Genre
            <input type="text" name="genre"  value="<?= $genre; ?>">
        </label>
        <label>Réalisateur
            <input type="text" name="realisateur"  value="<?= $realisateur; ?>">
        </label>
        <label>Description
            <input type="text" name="description"  value="<?= $description; ?>">
        </label>
        <label>Durée
            <input type="text" name="duree"  value="<?= $duree; ?>">
        </label>
        <input type="submit" value="save">
    </form>
    
</body>
</html>
